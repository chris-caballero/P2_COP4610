
//empty.c file required for part 1
#include <unistd.h>
int main() {
    return 0;
}
